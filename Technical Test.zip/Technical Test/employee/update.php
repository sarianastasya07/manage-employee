<?php
// include database connection file
include 'koneksi.php';
 $name= $_POST['name'];
 $employee_id=$_POST['employee_id'];
 $department=$_POST['department'];
 $job=$_POST['job'];
 $email=$_POST['email'];
 $result = mysqli_query($koneksi, "UPDATE employee SET
name='$name',employee_id='$employee_id',department='$department',job='$job',email='$email' WHERE name='$name'");
 // Redirect to homepage to display updated user in list
 header("Location: index.php");
?>