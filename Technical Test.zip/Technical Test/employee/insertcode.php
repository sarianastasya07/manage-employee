<?php


//create connection to database
$conn = mysqli_connect("localhost", "root", "", "form");


if (isset($_POST['insertdata']))
{
    $name = $_POST['name'];
	$employee_id = $_POST['employee_id'];
    $department = $_POST['department'];
    $job = $_POST['job'];
    $email = $_POST['email'];
    var_dump($name, $employee_id, $department, $job, $email,);

    $query = mysqli_query ($conn, "INSERT INTO `employee` (`name`, `employee_id`, `department`, `job`, `email`) VALUES ('$name', '$employee_id', '$department', '$job', '$email')")
    or die(mysqli_error($conn));

    //$result = mysqli_query($conn, $query);
    $query_run = mysqli_query($conn, $query);

    if ($query)
    {
        echo '<script> alert("Data Saved"); </script>';
        header('Location: form.php');
    }
    else
    {
        echo '<script> alert("Data Not Saved"); </script>';
    }

}

?>