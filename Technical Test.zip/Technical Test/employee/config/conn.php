<?php
$sql_details = array(
    'email' => 'root',
    'pass' => '',
    'db'   => 'form',
    'host' => 'localhost'
);
$conn = $sql_details;
