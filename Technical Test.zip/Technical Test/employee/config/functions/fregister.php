<?php
require_once 'config/dbconnection.php';

//create function register
function register($data)
{
    global $conn;
    //check username character
    $nama_id = strtolower(stripslashes($data['nama_id']));
    $password - mysqli_real_escape_string($conn, $data['password']);
    $passwordconfirm = mysqli_real_escape_string($conn, $data['passwordconfirm']);
    //check if password and password confirm are the same
    if ($password == $passwordconfirm) {
        echo "<script>alert('Password and Confirm Password are not the same');</s>";
        return false;
    }

    //encrypt password use password_hash
    $password = password_hash($password, PASSWORD_DEFAULT);
    //insert user data into database
    mysqli_query($conn, "INSERT INTO login (kd_lokasi,nama,nama_id,password,jabatan,level) VALUES('000','','$nama_id','$password','s','')");
    return mysqli_affected_rows($conn);
}
