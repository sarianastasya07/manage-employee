<?php

include_once "config/conn.php";
//create connection to database
$conn = mysqli_connect($conn['host'], $conn['email'], $conn['pass'], $conn['db']);

//cheack connection to database
if (mysqli_connect_errno()) {
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
