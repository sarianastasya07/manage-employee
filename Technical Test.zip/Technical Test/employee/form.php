<!DOCTYPE html>
<html lang="en">
<head>
<meta charsets="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<title> FORM EMPLOYEE </title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.2.1/dist/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
</head>

<body class="bg-info">
<div class="container">
	<div class="jumbotron">
		
			<h2> Employee Data </h2>
			<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#dataaddmodal ">
				Add Data
			</button>

<br>
<br>
            <div type="button" class="btn btn-primary" >
                <a href="index.php"> Back</a>
            </div>

<div class="modal fade" id="dataaddmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Silahkan Isi Data Pada Kolom Tersedia!</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

	  <form action="insertcode.php " method="POST">
	  <div class="modal-body">
			
			    <div class="form-group">
							<label>Employee Name </label>
							<input type="text" name="name" class="form-control" placeholder="Masukkan nama ">
				</div>
			
				<div class="form-group">
							<label>Employee ID </label>
							<input type="text"  name="employee_id"class="form-control" placeholder="Masukkan employee id ">
				</div>

				<div class="form-group">
							<label>Department </label>
							<input type="text"  name="department" class="form-control" placeholder="Masukkan department anda">
				</div>

				<div class="form-group">
							<label>Job Title  </label>
							<input type="text" name="job" class="form-control" placeholder="Masukkan job title anda">
				</div>

				<div class="form-group">
							<label>Email </label>
							<input type="text" name="email" class="form-control" placeholder="Masukkan email" rows="3">
				</div>

      </div>
      <div class="modal-footer">
        <button type="submit" name="insertdata" class="btn btn-primary">Kirim Data</button>
      </div>
	  </form>

    </div>
	
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.6/dist/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.2.1/dist/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
</body>
</html>