<?php
// include database connection file
include 'koneksi.php';
$name = $_GET['name'];
$result = mysqli_query($koneksi, "DELETE FROM employee WHERE name='$name'");
header("Location:index.php");
?>